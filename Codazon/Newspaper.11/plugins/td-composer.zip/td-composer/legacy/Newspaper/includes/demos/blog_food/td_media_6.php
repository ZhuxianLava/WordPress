<?php
td_demo_media::add_image_to_media_gallery('td_logo_footer',                   'http://demo_content.tagdiv.com/Newspaper_6/blog_food/logo-footer.png');
td_demo_media::add_image_to_media_gallery('td_logo_mobile',                     'http://demo_content.tagdiv.com/Newspaper_6/blog_food/logo-mobile.png');
td_demo_media::add_image_to_media_gallery('td_pic_separator',                   'http://demo_content.tagdiv.com/Newspaper_6/blog_food/separator.png');
