<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/7.jpg');
//ads
td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/recl-small.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/recbig.jpg');