<?php
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/animals/p4.jpg");
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/animals/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_logo_footer',             'http://demo_content.tagdiv.com/Newspaper_6/animals/logo-footer.png');
