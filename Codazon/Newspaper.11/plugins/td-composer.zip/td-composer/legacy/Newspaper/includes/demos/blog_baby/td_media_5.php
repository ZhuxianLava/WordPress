<?php
td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/blog_baby/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/blog_baby/p4.jpg");
// ads
td_demo_media::add_image_to_media_gallery('td_blog_baby_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/blog_baby/ad-sidebar.jpg");

