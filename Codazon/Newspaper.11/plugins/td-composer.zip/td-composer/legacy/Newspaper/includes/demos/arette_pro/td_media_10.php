<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_18', 'https://cloud.tagdiv.com/demos/Newspaper/arette_pro/media/background-asset6.png');