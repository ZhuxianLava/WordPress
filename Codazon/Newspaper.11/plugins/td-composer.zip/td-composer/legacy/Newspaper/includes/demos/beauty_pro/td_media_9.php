<?php
td_demo_media::add_image_to_media_gallery('td_pic_logo', 'https://cloud.tagdiv.com/demos/Newspaper/beauty_pro/media/logo-bg.jpg');