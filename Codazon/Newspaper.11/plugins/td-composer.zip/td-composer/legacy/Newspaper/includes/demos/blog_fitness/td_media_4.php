<?php
td_demo_media::add_image_to_media_gallery('td_pic_10',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_fitness/10.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_11',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_fitness/11.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_12',                   "http://demo_content.tagdiv.com/Newspaper_6/blog_fitness/12.jpg");

