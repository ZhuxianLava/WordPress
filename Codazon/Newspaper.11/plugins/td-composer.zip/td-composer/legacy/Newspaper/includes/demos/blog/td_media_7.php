<?php
//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo_desktop',        'http://demo_content.tagdiv.com/Newspaper_6/blog/classic-blog-logo.png');
td_demo_media::add_image_to_media_gallery('td_pic_logo_footer',         'http://demo_content.tagdiv.com/Newspaper_6/blog/classic-blog-logo-footer.png');
//ads
td_demo_media::add_image_to_media_gallery('td_blog_full_ad',            "http://demo_content.tagdiv.com/Newspaper_6/blog/rec728.jpg");