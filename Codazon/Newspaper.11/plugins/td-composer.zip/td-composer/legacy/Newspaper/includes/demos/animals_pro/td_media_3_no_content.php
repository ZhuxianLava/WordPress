<?php
//author bg image
td_demo_media::add_image_to_media_gallery('td_pic_author_page',                      "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/author-page.jpg");
//backgrounds
td_demo_media::add_image_to_media_gallery('bg_author',                         "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/xxx_bg_author_xxx.jpg");
td_demo_media::add_image_to_media_gallery('bg_home1',                          "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/xxx_bg_home1_xxx.jpg");
