<?php
td_demo_media::add_image_to_media_gallery('td_logo_mobile',             "http://demo_content.tagdiv.com/Newspaper_6/blog_health/logo-other.png");
td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/blog_health/p3.jpg");