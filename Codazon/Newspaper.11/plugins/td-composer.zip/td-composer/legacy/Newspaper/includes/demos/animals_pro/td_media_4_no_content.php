<?php
td_demo_media::add_image_to_media_gallery('bg_home2',                          "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/xxx_bg_home2_xxx.jpg");
td_demo_media::add_image_to_media_gallery('bg_home3',                          "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/xxx_bg_home3_xxx.jpg");
td_demo_media::add_image_to_media_gallery('bg_search',                         "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/xxx_bg_search_xxx.jpg");