<?php
// featured images
td_demo_media::add_image_to_media_gallery('td_pic_1',                               "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/1.jpg");

//logo symbol
td_demo_media::add_image_to_media_gallery('td_logo_symbol',                         'http://demo_content.tagdiv.com/Newspaper_6/animals_pro/logo-symbol.png');

//404 image
td_demo_media::add_image_to_media_gallery('td_pic_404',                             "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/404.png");

