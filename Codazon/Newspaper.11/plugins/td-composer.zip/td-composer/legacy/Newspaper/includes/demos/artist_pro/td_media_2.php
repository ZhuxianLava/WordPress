<?php
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/47.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/46.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/artist_pro/media/45.jpg');
