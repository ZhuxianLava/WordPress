<?php
/**
 * Plugin Name: tagDiv Opt-In Builder
 * Plugin URI: http://tagdiv.com
 * Description: Generate leads and increase conversion rates with opt-in content lockers and subscription lists.  tagDiv Opt-In Builder helps you easily create content lockers, subscribing lists (membership) and gives your visitors a compelling reason to enter their email address (opt-in) to unlock your content.
 * Version: 1.0
 * Author: tagDiv
 * Author URI: http://tagdiv.com
 *
 * @package td-subscription\td-subscription
 *
 *
 */

defined( 'ABSPATH' ) || exit;

if ( !defined( 'TDS_PLUGIN_FILE' ) ) {
	define( 'TDS_PLUGIN_FILE', __FILE__ );
}

// hash
define( 'TD_SUBSCRIPTION', '18da952bde8fab1875ba66b9c5072e53' );

// the deploy mode: dev or deploy  - it's set to deploy automatically on deploy
define( "TDS_DEPLOY_MODE", 'deploy' );

//version check
require_once('tds_version_check.php');

if ( !defined( 'TDS_URL' ) ) {
	define( 'TDS_URL', plugins_url('td-subscription') );
}

if ( !defined( 'TDS_PATH' ) ) {
	define( 'TDS_PATH', dirname(__FILE__) );
}

// main tds class
require_once('includes/td_subscription.php');
td_subscription::instance();



