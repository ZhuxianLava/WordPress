/* global jQuery, window, document */
/* global tds_leads_form_submit_data */
/* global td_read_site_cookie, td_set_cookies_life */

jQuery( function( $ ) {

    $(window).on( 'load', function () {

        return;

        window.tds_set_cookie = function(cname, cvalue, days) {
            var d = new Date();
            d.setTime( d.getTime() + ( days*24*60*60*1000 ) );
            var expires = "expires=" + d.toUTCString();
            document.cookie = cname + "=" + encodeURIComponent( cvalue ) + "; " + expires + "; path=/";
        };

        // read the cookie
        var tds_leads_cookie = td_read_site_cookie( 'tds-leads-cookie' );
        console.log(tds_leads_cookie);

        // check for errors
        if ( tds_leads_form_submit_data.has_errors ) {

            console.log('%c tds_leads_form_submit_data.has_errors', 'color: orangered;');
            console.log(tds_leads_form_submit_data.errors);

        // no errors
        } else {

            console.log('%c tds_leads_form_submit_data no errors', 'color: green;');

            // read submit data
            var new_lead_data =  tds_leads_form_submit_data.result.new_lead_data;

            console.log(new_lead_data);

            // setting cookie .. 86400000 is the number of milliseconds in a day
            td_set_cookies_life( [ 'tds-leads-cookie', JSON.stringify(new_lead_data), 10 * 86400000 ] );

        }

    });

});