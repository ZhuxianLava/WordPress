<div class="td-meta-box-inside">

	<div class="td-page-option-panel td-post-option-general td-page-option-panel-active">

<!--        <pre>-->
            <?php //print_r($mb); ?>
            <?php //print_r( get_post_meta( $mb->current_post_id, 'tds_locker_settings', true ) ); ?>
<!--        </pre>-->

        <div class="td-meta-box-col td-meta-box-col-layout">
            <!-- locker title -->
            <div class="td-meta-box-row">
                <?php
                    $mb->the_field('tds_title');
                    $tds_title_val = ( $mb->have_value() ) ? $mb->get_the_value() : "This Content Is Only For Subscribers";
                ?>
                <span class="td-page-o-custom-label">Locker Title:</span>
                <input id="tds-title" class="td-input-text-post-settings" type="text" name="<?php $mb->the_name(); ?>" value="<?php echo $tds_title_val; ?>" />
                <span class="td-page-o-info">Type a header which attracts attention or calls to action. You can leave this field empty.</span>
            </div>

            <!-- locker message -->
            <div class="td-meta-box-row">
                <?php
                    $mb->the_field('tds_message');
                    $tds_message_val = ( $mb->have_value() ) ? $mb->get_the_value() : "Please subscribe to unlock this content. Enter your email to get access.";
                ?>
                <span class="td-page-o-custom-label td_text_area_label">Locker Message:</span>
                <textarea id="tds-message" name="<?php $mb->the_name(); ?>" class="td-textarea-message"><?php echo $tds_message_val; ?></textarea>
                <span class="td-page-o-info">Type a message which will appear under the header.</span>
            </div>

            <!-- locker input placeholder -->
            <div class="td-meta-box-row">
                <?php
                    $mb->the_field('tds_input_placeholder');
                    $tds_input_placeholder_val = ( $mb->have_value() ) ? $mb->get_the_value() : "Please enter your email address";
                ?>
                <span class="td-page-o-custom-label">Input Placeholder:</span>
                <input id="tds-input-placeholder" class="td-input-text-post-settings" type="text" name="<?php $mb->the_name(); ?>" value="<?php echo $tds_input_placeholder_val; ?>"/>
                <span class="td-page-o-info">Type a placeholder. You can leave this field empty.</span>
            </div>
        </div>

        <div class="td-meta-box-col">
            <!-- locker submit button text -->
            <div class="td-meta-box-row">
                <?php
                    $mb->the_field('tds_submit_btn_text');
                    $tds_submit_btn_text_val = ( $mb->have_value() ) ? $mb->get_the_value() : "Subscribe to unlock";
                ?>
                <span class="td-page-o-custom-label">Button Text:</span>
                <input id="tds-submit-btn-text" class="td-input-text-post-settings" type="text" name="<?php $mb->the_name(); ?>" value="<?php echo $tds_submit_btn_text_val; ?>"/>
                <span class="td-page-o-info">The text on the button. Call to action!</span>
            </div>

            <!-- locker after button text -->
            <div class="td-meta-box-row">
                <?php
                    $mb->the_field('tds_after_btn_text');
                    $tds_after_btn_text_val = ( $mb->have_value() ) ? $mb->get_the_value() : "Your email address is 100% safe from spam!";
                ?>
                <span class="td-page-o-custom-label">After Button Text:</span>
                <input id="tds-after-btn-text" class="td-input-text-post-settings" type="text" name="<?php $mb->the_name(); ?>" value="<?php echo $tds_after_btn_text_val; ?>"/>
                <span class="td-page-o-info">The text below the button. Guarantee something.</span>
            </div>

            <!-- locker privacy policy message -->
            <div class="td-meta-box-row">
                <?php
                    $mb->the_field('tds_pp_msg');
                    $tds_pp_msg_val = ( $mb->have_value() ) ? $mb->get_the_value() : 'I consent to processing of my data according to <a href="#">Terms of Use</a> & <a href="#">Privacy Policy</a>';
                ?>
                <span class="td-page-o-custom-label td_text_area_label">Privacy Policy Consent Message:</span>
                <textarea id="tds-pp-msg" name="<?php $mb->the_name(); ?>" class="td-textarea-message"><?php echo $tds_pp_msg_val; ?></textarea>
                <span class="td-page-o-info">Consent Message & Checkbox for GDPR compatibility.</span>
            </div>
        </div>

	</div>

</div>